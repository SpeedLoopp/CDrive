

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Paylaşım Linklerim</h1>

<div class="card">
    <?php if($links->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Dosya</th>
                    <th>Link</th>
                    <th>Erişim</th>
                    <th>Durum</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($link->file->original_name); ?></td>
                    <td>
                        <a href="<?php echo e(route('link.show', $link->custom_link)); ?>" target="_blank" style="color: #4facfe;">
                            <?php echo e(url('/l/' . $link->custom_link)); ?>

                        </a>
                    </td>
                    <td><?php echo e($link->access_count); ?></td>
                    <td>
                        <?php if($link->isAccessible()): ?>
                            <span style="color: #27ae60;">✓ Aktif</span>
                        <?php else: ?>
                            <span style="color: #e74c3c;">✗ Pasif</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($link->created_at->format('d.m.Y H:i')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('links.destroy', $link)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; opacity: 0.6;">Henüz link oluşturmadınız.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\dashboard\links\index.blade.php ENDPATH**/ ?>