

<?php $__env->startSection('content'); ?>
<div style="max-width: 400px; margin: 80px auto;">
    <div class="card">
        <h2 style="margin-bottom: 20px; text-align: center;">Giriş Yap</h2>
        
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            
            <label>E-posta</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: #e74c3c; font-size: 12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label>Şifre</label>
            <input type="password" name="password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: #e74c3c; font-size: 12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label style="display: flex; align-items: center; margin: 15px 0;">
                <input type="checkbox" name="remember" style="width: auto; margin-right: 10px;">
                Beni Hatırla
            </label>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">
                Giriş Yap
            </button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="<?php echo e(route('password.request')); ?>" style="color: #4facfe;">Şifremi Unuttum</a>
            <br><br>
            <a href="<?php echo e(route('register')); ?>" style="color: #4facfe;">Hesabın yok mu? Kayıt Ol</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\auth\login.blade.php ENDPATH**/ ?>