

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Reklam Düzenle</h1>

<div class="card">
    <form method="POST" action="<?php echo e(route('admin.ads.update', $ad)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <label>Başlık</label>
        <input type="text" name="title" value="<?php echo e(old('title', $ad->title)); ?>">
        
        <label>Tip</label>
        <select name="type" required>
            <option value="header" <?php echo e($ad->type == 'header' ? 'selected' : ''); ?>>Üst Banner</option>
            <option value="footer" <?php echo e($ad->type == 'footer' ? 'selected' : ''); ?>>Alt Banner</option>
            <option value="popup" <?php echo e($ad->type == 'popup' ? 'selected' : ''); ?>>Popup</option>
            <option value="sidebar" <?php echo e($ad->type == 'sidebar' ? 'selected' : ''); ?>>Yan Panel</option>
        </select>
        
        <label>İçerik (HTML)</label>
        <textarea name="content" rows="10" required><?php echo e(old('content', $ad->content)); ?></textarea>
        
        <label>Görüntüleme Sırası</label>
        <input type="number" name="display_order" value="<?php echo e(old('display_order', $ad->display_order)); ?>">

        <div style="margin-top: 20px;">
            <button type="submit" class="btn btn-primary">Güncelle</button>
            <a href="<?php echo e(route('admin.ads.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\admin\ads\edit.blade.php ENDPATH**/ ?>