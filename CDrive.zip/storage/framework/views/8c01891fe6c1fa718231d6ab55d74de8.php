

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Reklam Yönetimi</h1>

<div style="margin-bottom: 20px;">
    <a href="<?php echo e(route('admin.ads.create')); ?>" class="btn btn-primary">Yeni Reklam Ekle</a>
</div>

<div class="card">
    <?php if($ads->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Başlık</th>
                    <th>Tip</th>
                    <th>Sıra</th>
                    <th>Durum</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ad->title ?? 'Başlıksız'); ?></td>
                    <td><?php echo e($ad->type); ?></td>
                    <td><?php echo e($ad->display_order); ?></td>
                    <td>
                        <?php if($ad->active): ?>
                            <span style="color: #27ae60;">✓ Aktif</span>
                        <?php else: ?>
                            <span style="color: #e74c3c;">✗ Pasif</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($ad->created_at->format('d.m.Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.ads.edit', $ad)); ?>" class="btn btn-primary">Düzenle</a>
                        
                        <form method="POST" action="<?php echo e(route('admin.ads.toggle', $ad)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">
                                <?php echo e($ad->active ? 'Pasifleştir' : 'Aktifleştir'); ?>

                            </button>
                        </form>
                        
                        <form method="POST" action="<?php echo e(route('admin.ads.destroy', $ad)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($ads->links()); ?>

    <?php else: ?>
        <p style="text-align: center; opacity: 0.6;">Reklam bulunamadı.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\admin\ads\index.blade.php ENDPATH**/ ?>