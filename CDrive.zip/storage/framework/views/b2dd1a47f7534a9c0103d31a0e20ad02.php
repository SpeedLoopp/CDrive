

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Dosyalarım</h1>

<div class="card">
    <h3 style="margin-bottom: 20px;">Dosya Yükle</h3>
    <form method="POST" action="<?php echo e(route('files.upload')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="file" required>
        <input type="text" name="folder" placeholder="Klasör adı (opsiyonel)">
        <button type="submit" class="btn btn-primary">Yükle</button>
    </form>
</div>

<div class="card">
    <h3 style="margin-bottom: 20px;">Dosya Listesi</h3>
    
    <?php if($files->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Dosya Adı</th>
                    <th>Boyut</th>
                    <th>Klasör</th>
                    <th>İndirme</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($file->original_name); ?></td>
                    <td><?php echo e($file->formatted_size); ?></td>
                    <td><?php echo e($file->folder ?? '-'); ?></td>
                    <td><?php echo e($file->download_count); ?></td>
                    <td><?php echo e($file->created_at->format('d.m.Y H:i')); ?></td>
                    <td>
                        <a href="<?php echo e(route('files.download', $file)); ?>" class="btn btn-success">İndir</a>
                        <a href="<?php echo e(route('links.create', $file)); ?>" class="btn btn-primary">Link Oluştur</a>
                        <form method="POST" action="<?php echo e(route('files.destroy', $file)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($files->links()); ?>

    <?php else: ?>
        <p style="text-align: center; opacity: 0.6;">Henüz dosya yüklemediniz.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\dashboard\files\index.blade.php ENDPATH**/ ?>