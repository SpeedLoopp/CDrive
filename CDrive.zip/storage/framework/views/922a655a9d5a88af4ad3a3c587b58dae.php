

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Yeni Reklam Ekle</h1>

<div class="card">
    <form method="POST" action="<?php echo e(route('admin.ads.store')); ?>">
        <?php echo csrf_field(); ?>
        
        <label>Başlık</label>
        <input type="text" name="title" value="<?php echo e(old('title')); ?>">
        
        <label>Tip</label>
        <select name="type" required>
            <option value="header">Üst Banner</option>
            <option value="footer">Alt Banner</option>
            <option value="popup">Popup</option>
            <option value="sidebar">Yan Panel</option>
        </select>
        
        <label>İçerik (HTML)</label>
        <textarea name="content" rows="10" required><?php echo e(old('content')); ?></textarea>
        
        <label>Görüntüleme Sırası</label>
        <input type="number" name="display_order" value="<?php echo e(old('display_order', 0)); ?>">

        <div style="margin-top: 20px;">
            <button type="submit" class="btn btn-primary">Kaydet</button>
            <a href="<?php echo e(route('admin.ads.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\admin\ads\create.blade.php ENDPATH**/ ?>