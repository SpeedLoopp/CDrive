

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Dosya Yönetimi</h1>

<div class="card">
    <?php if($files->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Dosya</th>
                    <th>Kullanıcı</th>
                    <th>Boyut</th>
                    <th>İndirme</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($file->original_name); ?></td>
                    <td><?php echo e($file->user->name); ?></td>
                    <td><?php echo e($file->formatted_size); ?></td>
                    <td><?php echo e($file->download_count); ?></td>
                    <td><?php echo e($file->created_at->format('d.m.Y H:i')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.files.destroy', $file)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Sil</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($files->links()); ?>

    <?php else: ?>
        <p style="text-align: center; opacity: 0.6;">Dosya bulunamadı.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\admin\files\index.blade.php ENDPATH**/ ?>