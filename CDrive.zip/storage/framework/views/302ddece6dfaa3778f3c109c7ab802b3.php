

<?php $__env->startSection('content'); ?>
<div style="max-width: 400px; margin: 80px auto;">
    <div class="card">
        <h2 style="margin-bottom: 20px; text-align: center;">Şifremi Unuttum</h2>
        
        <p style="margin-bottom: 20px; opacity: 0.8;">
            E-posta adresinizi girin, size şifre sıfırlama linki gönderelim.
        </p>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            
            <label>E-posta</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span style="color: #e74c3c; font-size: 12px;"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                Link Gönder
            </button>
        </form>

        <div style="text-align: center; margin-top: 20px;">
            <a href="<?php echo e(route('login')); ?>" style="color: #4facfe;">Giriş sayfasına dön</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>