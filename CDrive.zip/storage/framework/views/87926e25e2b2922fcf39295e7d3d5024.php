

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Kullanıcı Yönetimi</h1>

<div class="card">
    <?php if($users->count() > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Ad</th>
                    <th>E-posta</th>
                    <th>Rol</th>
                    <th>Durum</th>
                    <th>Kayıt</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td>
                        <?php if($user->is_active): ?>
                            <span style="color: #27ae60;">✓ Aktif</span>
                        <?php else: ?>
                            <span style="color: #e74c3c;">✗ Pasif</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->created_at->format('d.m.Y')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.users.toggle', $user)); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-primary">
                                <?php echo e($user->is_active ? 'Pasifleştir' : 'Aktifleştir'); ?>

                            </button>
                        </form>
                        
                        <?php if(!$user->isAdmin()): ?>
                            <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Emin misiniz?')">Sil</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        
        <?php echo e($users->links()); ?>

    <?php else: ?>
        <p style="text-align: center; opacity: 0.6;">Kullanıcı bulunamadı.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\admin\users\index.blade.php ENDPATH**/ ?>