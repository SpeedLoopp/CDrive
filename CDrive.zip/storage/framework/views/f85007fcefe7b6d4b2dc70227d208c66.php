

<?php $__env->startSection('content'); ?>
<h1 style="margin: 40px 0 20px;">Paylaşım Linki Oluştur</h1>

<div class="card">
    <h3 style="margin-bottom: 20px;">Dosya: <?php echo e($file->original_name); ?></h3>
    
    <form method="POST" action="<?php echo e(route('links.store', $file)); ?>">
        <?php echo csrf_field(); ?>
        
        <label>Özel Link Adı</label>
        <input type="text" name="custom_link" placeholder="ornek-dosya" required>
        <small style="opacity: 0.7;">Link: <?php echo e(url('/l/')); ?>/özel-link-adınız</small>
        <?php $__errorArgs = ['custom_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: #e74c3c; font-size: 12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label>Son Kullanma Tarihi (Opsiyonel)</label>
        <input type="datetime-local" name="expiration_date">
        <?php $__errorArgs = ['expiration_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span style="color: #e74c3c; font-size: 12px;"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <div style="margin-top: 20px;">
            <button type="submit" class="btn btn-primary">Link Oluştur</button>
            <a href="<?php echo e(route('files.index')); ?>" class="btn">İptal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LenovoPC\Desktop\CDrive\resources\views\dashboard\links\create.blade.php ENDPATH**/ ?>